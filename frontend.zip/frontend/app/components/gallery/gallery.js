import React, { Component } from 'react';
import {
  Container,
  Row,
  Col
} from 'reactstrap';
 import {withRouter, Link} from 'react-router-dom'
import './gallery.css';
class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      product: [],
    };
  }
  componentDidMount() {
    fetch('http://localhost:5000/users/readgly', {
      method: 'get',
    })
      .then(res => res.json())
      .then(product => this.setState({ product }));
  }

  card() {
    return this.state.product.map(data => (
      <Col lg="3">
       <Link  to="/filter"><img className="images"  alt="" src={data.images} /> </Link> 
      </Col>
    ));
  }

  render() {
    return (
     <div class="container-fluid">
      {/* <Row>
      <img src="https://assets.myntassets.com/f_webp,w_980,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2019/3/27/b1418eba-e250-4665-b37f-b04f81b18fa51553683205515-Brands-section.jpg"/></Row> */}
        <Row>{this.card()}</Row>
        </div>
    );
  }
}
export default Home;
