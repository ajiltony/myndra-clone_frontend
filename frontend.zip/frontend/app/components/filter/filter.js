
import React, { useState, useEffect } from "react";
import {Card,CardBody,CardTitle,CardImg,CardText,Button,Label,Form, FormGroup,Input,Row,Col,CardFooter} from 'reactstrap';
import axios from 'axios';
import './filter.css';
import $ from 'jquery';

function  Filter(){
   const [filterimage,setfilterimage]=useState([]);
   const [user,setUser]=useState([]);
   function onChange(e){
   setUser({...user,[e.target.name]:e.target.value})
     }
      function allClear(e){
      setUser([])
       }
       $("document").ready(()=>{
        $('.clearall').click(()=>{
            $('input[type="radio"]').prop('checked', false)
        });
      })
       if(user.product_name!='' || user.catagries!=''|| user.color!='' || user.discount!=''|| user.price!='' ){
            useEffect (()=>{
              axios
              .post("http://localhost:5000/users/getfilter",{...user})
              .then(res =>{
                // console.log("1",res);
                setfilterimage(res.data);
              })
              .catch(err=>{
                // console.log(err)
              })
            },[user]);
          }
          else{
            useEffect(()=>{
              axios
              .get('http://localhost:5000/users/getallfilter')
              .then(res=>{
                // console.log("product",res);
                setfilterimage(res.data)
              })
              .catch(err=>{
                // console.log(err)
              })
            },[]);
          }
         function productimg(){
  return filterimage.map(data =>{
    return (
      <Col lg="3">
      <Card className="hovereffect">
      <a href={`product/${data.product_code}`} style={{textDecoration: "none"}}>
       <CardImg className="img-responsive" src={data.filterimage[0]}></CardImg>
         <CardText className="img-responsive">{data.product_name} </CardText>
         <CardText className="img-responsive"> Rs.{data.price}</CardText>
       <CardFooter className="overlay">
             <h2><Button color="primary" >Add Card</Button></h2>
             <h2><Button color="primary">Buy Now</Button></h2>
         </CardFooter>
         </a> 
      </Card>
  
   </Col>
    )
  });
}

return(
        <div class="container-fluid">
            
               <p style={{marginLeft:20,marginTop:-20}}>Western Wear Dresses Menu - <span>27886 items</span></p>
               <h4 style={{marginLeft:20}}>FILTERS</h4><hr style={{width:"100%"}}/><button className="clearall" id="all" type="button"  value="" style={{backgroundColor:"skyblue",borderRadius:"100%" }} onClick={allClear}>clearall</button><br/>
               <Row>
               <Col xs="2">
               <Form className="rtcol">
               <FormGroup className="CATEGORIES" check>
                 <Label check><b>CATEGORIES</b></Label><br/>
                 
                <Input type="radio" name="catagries" value="T-shirt" onChange={onChange}/>{' '}T-shrt(2632)<br/>
                <Input type="radio" name="catagries" value="Casual Shirts" onChange={onChange}/>{' '}Casual Shirts (185)<br/>
                <Input type="radio" name="catagries" value="Formal Shirts" onChange={onChange} />{' '}Formal Shirts(25064)<br/>
                <Input type="radio" name="catagries" value="Jackets"  onChange={onChange}/>{' '}Jackets(5)
             <hr/>
               <Label className="filterbrand" check><b>BRAND</b></Label><br/>
                <Input type="text" className="brandinput" style={{display:"none"}}/>
                <Input type="radio" name="product_name" value="WROGN" onChange={onChange} />{' '}WROGN(1464)<br/>
                <Input type="radio" name="product_name" value="HIGHLANDER" onChange={onChange} />{' '}HIGHLANDER(1405)<br/>
                <Input type="radio" name="product_name" value="Peter England" onChange={onChange} />{' '}PETER ENGLAND(1081)<br/>
                <Input type="radio" name="product_name" value="LOCOMOTIVE" onChange={onChange} />{' '}LOCOMOTIVE(1030)<br/>
               <br/>
            <hr/> 
                <Label className="filterprice" check><b>PRICE</b></Label><br/>
                <Input type="radio" name="price" onChange={(e)=>{setUser({...user,price:{'$gte':301,'$lte':500}})}} />Rs. 301 to Rs. 500(27927)<br/>
                <Input type="radio" name="price" onChange={(e)=>{setUser({...user,price:{'$gte':501,'$lte':700}})}}/>Rs. 501 to Rs. 700(8)<br/>
                <Input type="radio" name="price" onChange={(e)=>{setUser({...user,price:{'$gte':701,'$lte':1000}})}}/>Rs. 701 to Rs. 1000(2)<br/>
                <br/>
                <hr/>
                <Label check className="brand"><b>COLOR</b></Label><br/>
                <Input type="radio" name="color" value="black" onChange={onChange} />{' '}<div className="black" />Black (6251)<br/>
                <Input type="radio" name="color" value="blue" onChange={onChange} />{' '}<div className="blue"  />Blue (2893)<br/>
                <Input type="radio" name="color" value="Grey" onChange={onChange} />{' '}<div className="Grey"  />Grey (3005)<br/>
                <Input type="radio" name="color" value="white" onChange={onChange} />{' '}<div className="white"  />White (1777)<br/>
                <Input type="radio" name="color" value="Red" onChange={onChange} />{' '}<div className="red" />Red (1407)<br/>
                <Input type="radio" name="color" value="green"onChange={onChange} />{' '}<div className="green"  />Green (1313)<br/>
                <br/>
                <hr/>
                <Label check><b>DISCOUNT RANGE</b></Label><br/>
                <Input type="radio" name="discount" value="10" onChange={onChange} />{' '}10% and above<br/>
                <Input type="radio" name="discount" value="20" onChange={onChange} />{' '}20% and above<br/>
                <Input type="radio" name="discount" value="30" onChange={onChange} />{' '}30% and above<br/>
                <Input type="radio" name="discount" value="40" onChange={onChange} />{' '}40% and above<br/>
                <Input type="radio" name="discount" value="50" onChange={onChange} />{' '}50% and above<br/>
                <br/>
                </FormGroup>
              </Form>
                </Col>
                <Col xs="10">
                <Row >
                {productimg()}
                </Row >
                <br/>
                </Col>
              </Row>
              
        </div>
      );

}
  export default Filter
