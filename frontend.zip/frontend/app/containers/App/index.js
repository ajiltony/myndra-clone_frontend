/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-first-prop-new-line */
/* eslint-disable indent */
/* eslint-disable prettier/prettier */
import React from 'react';
import Header from '../../components/Header/header';
 import Footer from '../../components/Footer/footer';
import Slick from '../../components/Slick/slick';
import Register from '../../components/registaration/Register';
import Edit from '../../components/registaration/editpf';
import Login from '../../components/registaration/login';
import Profile from "../../components/registaration/Profile";
import Gallery from "../../components/gallery/gallery";
import Filter from "../../components/filter/filter";
import Product from "../../components/products/product"
import bag from '../../components/Addcard/addcard'
import Address from '../../components/Address/address'
import Addressheader from '../../components/Address/addressHeader'
import Order from '../../components/Order/order'
import OrderDetails from '../../components/Order/orderDetails'
import 'bootstrap/dist/css/bootstrap.css';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
// import { Helmet } from 'react-helmet';
// import styled from 'styled-components';
// import { Switch, Route } from 'react-router-dom';

// import HomePage from 'containers/HomePage/Loadable';
// import FeaturePage from 'containers/FeaturePage/Loadable';
// import NotFoundPage from 'containers/NotFoundPage/Loadable';
// import Header from 'components/Header';
// import Footer from 'components/Footer';
// import GlobalStyle from '../../global-styles';
// const AppWrapper = styled.div`
//   max-width: calc(768px + 16px * 2);
//   margin: 0 auto;
//   display: flex;
//   min-height: 100%;
//   padding: 0 16px;
//   flex-direction: column;
// `;

export default function App() {
  return (
    <Router>
    <Header />
      <Switch>
        <Route path='/' exact render={props =>
          <div>
  <Slick />
  <Gallery/>
  </div>
  } />
<Route path='/register' component={Register}/>
<Route path='/edit' component={Edit} />
<Route path='/login' component={Login}/>
<Route exact path="/profile" component={Profile} />
<Route path='/filter' component={Filter}/>
<Route path='/product/:product_code' component={Product}/>
<Route path='/bag' component={bag}/>
<Route path='/address' exact render={props =>
          <div>
             <Addressheader/>
  <Address />
  </div>
  } />
  <Route path='/order' exact component={Order}/>
  <Route path='/order/:orderId' exact component={OrderDetails}/>
</Switch>
  <Footer />
  </Router>
  );
}